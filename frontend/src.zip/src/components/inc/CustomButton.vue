<template>
    <button>
        
    </button>
</template>

<script>
    export default {
        props: ['label', 'inverted'],
        methods: {

        }
    }
</script>

<style>

</style>